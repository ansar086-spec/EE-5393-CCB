k 1: u 1 k 1: 0.05
u 1 Qin 2: g 1 Qp 1 u 1 : 500
g 2 : g 1 : 500
u 1 : V 1 : 50
Qp 1 : Qin 1 : 5
g 1 : M 1 : 1
N 1 Key 1 : P 1 : 0.00025
P 1 M 1 : P 1 Mp 1 R 1 : 500
P 1 : Q 1 : 0.5
Q 1 Mp 1 : Q 1 M 1 : 500
Q 1 : Key 1 : 0.5