import random
import numpy as np

# -----------------------------
# Parameters
# -----------------------------
k1 = 1
k2 = 2
k3 = 3

initial_state = [9, 8, 7]

num_simulations = 50000
num_steps = 7   # exactly 7 reaction events


# -----------------------------
# One 7-step Simulation
# -----------------------------
def simulate_7_steps():
    x1, x2, x3 = initial_state

    for _ in range(num_steps):

        # Compute propensities
        a1 = k1 * (x1 * (x1 - 1) / 2) * x2 if x1 >= 2 and x2 >= 1 else 0
        a2 = k2 * x1 * (x3 * (x3 - 1) / 2) if x1 >= 1 and x3 >= 2 else 0
        a3 = k3 * x2 * x3 if x2 >= 1 and x3 >= 1 else 0

        a0 = a1 + a2 + a3

        if a0 == 0:
            break

        r = random.uniform(0, a0)

        # R1
        if r < a1:
            x1 -= 2
            x2 -= 1
            x3 += 4

        # R2
        elif r < a1 + a2:
            x1 -= 1
            x3 -= 2
            x2 += 3

        # R3
        else:
            x2 -= 1
            x3 -= 1
            x1 += 2

    return x1, x2, x3


# -----------------------------
# Run Monte Carlo
# -----------------------------
X1_vals = []
X2_vals = []
X3_vals = []

for _ in range(num_simulations):
    x1, x2, x3 = simulate_7_steps()
    X1_vals.append(x1)
    X2_vals.append(x2)
    X3_vals.append(x3)

# -----------------------------
# Compute Mean & Variance
# -----------------------------
mean_X1 = np.mean(X1_vals)
var_X1 = np.var(X1_vals)

mean_X2 = np.mean(X2_vals)
var_X2 = np.var(X2_vals)

mean_X3 = np.mean(X3_vals)
var_X3 = np.var(X3_vals)

print("After 7 steps:\n")

print("X1 -> Mean:", mean_X1, "Variance:", var_X1)
print("X2 -> Mean:", mean_X2, "Variance:", var_X2)
print("X3 -> Mean:", mean_X3, "Variance:", var_X3)