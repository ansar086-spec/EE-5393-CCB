
for ($i = 1; $i -le 10; $i++) {
    Write-Host "Running simulation with MOI = $i ..."

    # Read lambda.in and replace the MOI line
    $content = Get-Content lambda.in
    $content = $content -replace "^MOI \d+ N", "MOI $i N"
    $content | Set-Content lambda.in

    # Run the simulation and save output
    ./aleae.exe lambda.in lambda.r 1000 -1 0 > "result_$i.txt"

    Write-Host "  Saved to result_$i.txt"
}

Write-Host "Done! Results saved in result_1.txt through result_10.txt"