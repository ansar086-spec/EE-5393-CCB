import random
import math

# Gillespie simulation for the given CRN

def simulate_once(
    x1_init=110, x2_init=26, x3_init=55,
    max_steps=1_000_000
):
    x1, x2, x3 = x1_init, x2_init, x3_init

    for _ in range(max_steps):

        # Check outcomes
        if x1 >= 150:
            return "C1"
        if x2 < 10:
            return "C2"
        if x3 > 100:
            return "C3"

        # Propensities (rates)
        a1 = 0.5 * x1 * (x1 - 1) * x2          # R1
        a2 = x1 * x3 * (x3 - 1)                # R2
        a3 = 3 * x2 * x3                       # R3

        a0 = a1 + a2 + a3
        if a0 == 0:
            return None  # system stuck

        # Choose reaction
        r = random.random() * a0

        if r < a1:
            # R1: 2X1 + X2 -> 4X3
            x1 -= 2
            x2 -= 1
            x3 += 4
        elif r < a1 + a2:
            # R2: X1 + 2X3 -> 3X2
            x1 -= 1
            x3 -= 2
            x2 += 3
        else:
            # R3: X2 + X3 -> 2X1
            x2 -= 1
            x3 -= 1
            x1 += 2

    return None


def estimate_probabilities(trials=10000):
    counts = {"C1": 0, "C2": 0, "C3": 0}

    for _ in range(trials):
        result = simulate_once()
        if result in counts:
            counts[result] += 1

    for k in counts:
        counts[k] /= trials

    return counts


if __name__ == "__main__":
    probs = estimate_probabilities(trials=20000)
    print("Estimated probabilities:")
    print("Pr(C1) =", probs["C1"])
    print("Pr(C2) =", probs["C2"])
    print("Pr(C3) =", probs["C3"])